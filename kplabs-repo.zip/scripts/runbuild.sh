#!/bin/bash
chmod +x /tmp/kplabs-repo
/tmp/kplabs-repo > /tmp/kplabs-repo-log.txt
