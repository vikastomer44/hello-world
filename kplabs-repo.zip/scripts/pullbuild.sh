#!/bin/bash
aws s3 cp s3://mycodedeploylab09092020/kplabs-repo.zip /tmp/


